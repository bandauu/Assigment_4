package com.example.assigment_4.Model;


import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Value;
import org.hibernate.validator.constraints.Range;

@Data
@AllArgsConstructor
public class Employee {
    @NotEmpty(message = "ID can't be empty")
    @Size( min = 3 , message="ID must be more than 2 char")
    private String ID;
    @NotEmpty(message = "Name can't be empty")
    @Size( min = 5 , message="Name must be more than 4 char")
    private String name;
    @NotNull(message = "Age can't be empty")
    @Min( value = 26 , message="you must be older than 25")
    @Positive(message = "age must be positive")
    private int age;
    @AssertFalse(message = "onLeave must be false")
    private boolean onLeave;
    @NotNull(message = "employment Year can't be empty")
    @Range(min = 1980, max = 2022 , message = "employment Year must be valid")
    @Positive(message = "employment Year must be positive")

    private int employmentYear;
    @NotNull(message = "annualLeave can't be empty")
    @Positive(message = "annualLeave must be positive")
    private int annualLeave;


}
