package com.example.assigment_4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assigment4Application {

    public static void main(String[] args) {
        SpringApplication.run(Assigment4Application.class, args);
    }

}
