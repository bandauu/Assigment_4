package com.example.assigment_4.Controller;

import com.example.assigment_4.ApiResponse;
import com.example.assigment_4.Model.Employee;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("api/v1")
public class EmployeeController {
    ArrayList<Employee> emp = new ArrayList<>();

    @GetMapping("/employee")
    public ArrayList<Employee> getEmp(){
        return emp;
    }

    @PostMapping("/add")
    public ResponseEntity addEmp(@RequestBody @Valid Employee employee , Errors error){
        if (error.hasErrors()){
            String M = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(M);
        }
        emp.add(employee);
        return ResponseEntity.status(201).body(new ApiResponse("Employee Added!"));
    }

    @PutMapping("/update/{index}")
    public ResponseEntity updateEmp(@PathVariable int index, @RequestBody @Valid Employee employee , Errors error){
        if (error.hasErrors()){
            String M = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(M);
        }
        emp.set(index,employee);
        return ResponseEntity.status(200).body(new ApiResponse("Employee Updated!"));
    }

    @DeleteMapping("/{index}")
    public ApiResponse deleteUser(@PathVariable int index){
        emp.remove(index);
        return new ApiResponse("Employee deleted !");
    }
}
