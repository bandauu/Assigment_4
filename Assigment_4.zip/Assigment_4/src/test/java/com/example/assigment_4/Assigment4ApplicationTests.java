package com.example.assigment_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assigment4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
